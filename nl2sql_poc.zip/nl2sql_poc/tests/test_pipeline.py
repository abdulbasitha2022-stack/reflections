"""
Pipeline tests. The LLM is scripted, so no API key or network is needed.
The integration test at the bottom runs against a real Postgres if TEST_DATABASE_URL is set
(the URL of the poc_readonly user), otherwise it is skipped.
"""
import json
import os

import pytest

from app.db import DBProvider, QueryError, QueryResult
from app.llm import LLMProvider, LLMResponse
from app.pipeline import Pipeline, parse_response


# ------------------------------------------------------------------ fakes
class ScriptedLLM(LLMProvider):
    name = "scripted"

    def __init__(self, replies):
        super().__init__({"model": "scripted-1"})
        self.replies, self.calls = list(replies), []

    def complete(self, system, messages):
        self.calls.append([dict(m) for m in messages])
        return LLMResponse(self.replies.pop(0), input_tokens=100, output_tokens=20,
                           extra={"cache_read_tokens": 80})


class FakeDB(DBProvider):
    dialect = "postgres"

    def __init__(self, fail_first=None):
        self.ran, self.fail_first = [], fail_first

    def describe(self, tables):
        return "membership_sample(ui TEXT, master_associate TEXT, autobill_flag TEXT)"

    def execute_readonly(self, sql, max_rows):
        self.ran.append(sql)
        if self.fail_first and len(self.ran) == 1:
            raise QueryError(self.fail_first)
        return QueryResult(["n"], [(42,)], False)


CFG = {"db": {"allowed_tables": ["membership_sample"], "max_rows": 1000},
       "context": {"files": [], "extra_rules": "test rule"},
       "pipeline": {"max_retries": 2}}


def make(replies, tmp_path, db=None):
    cfg = json.loads(json.dumps(CFG))
    cfg["pipeline"]["log_file"] = "log.jsonl"
    llm, db = ScriptedLLM(replies), db or FakeDB()
    return Pipeline(llm, db, cfg, base_dir=tmp_path), llm, db


# ------------------------------------------------------------------ parsing
def test_parse_sql_with_assumptions():
    p = parse_response("ASSUMPTION: last 6 months\nASSUMPTION: category S\n"
                       "```sql\nSELECT 1\n```")
    assert p.kind == "sql" and p.sql == "SELECT 1" and len(p.assumptions) == 2


def test_parse_clarify():
    p = parse_response("CLARIFY: Which tier precedence should I use?")
    assert p.kind == "clarify" and "precedence" in p.clarification


def test_parse_unfenced_sql():
    assert parse_response("SELECT 1").kind == "sql"


def test_parse_garbage():
    assert parse_response("Sure! Happy to help.").kind == "invalid"


# ------------------------------------------------------------------ pipeline
def test_happy_path_logs_and_enforces_limit(tmp_path):
    pipe, llm, db = make(["ASSUMPTION: proxy used\n```sql\nSELECT count(*) AS n "
                          "FROM membership_sample\n```"], tmp_path)
    res = pipe.ask("how many?")
    assert res.status == "ok" and res.rows == [(42,)] and res.assumptions == ["proxy used"]
    assert "LIMIT 1000" in db.ran[0]                       # cap injected before execution
    entry = json.loads((tmp_path / "log.jsonl").read_text().splitlines()[0])
    assert entry["status"] == "ok" and entry["input_tokens"] == 100 and entry["provider"] == "scripted"


def test_clarify_short_circuits(tmp_path):
    pipe, llm, db = make(["CLARIFY: Which time window?"], tmp_path)
    res = pipe.ask("show trends")
    assert res.status == "clarify" and res.clarification == "Which time window?" and db.ran == []


def test_dangerous_sql_never_reaches_db_and_model_gets_feedback(tmp_path):
    pipe, llm, db = make(["```sql\nDELETE FROM membership_sample\n```",
                          "```sql\nSELECT count(*) AS n FROM membership_sample\n```"], tmp_path)
    res = pipe.ask("clean up the data")
    assert res.status == "ok" and res.attempts == 2
    assert len(db.ran) == 1 and db.ran[0].upper().startswith("SELECT")   # DELETE never executed
    assert "That failed" in llm.calls[1][-1]["content"]                  # error was sent back


def test_db_error_is_fed_back_and_retried(tmp_path):
    pipe, llm, db = make(["```sql\nSELECT bad_col FROM membership_sample\n```",
                          "```sql\nSELECT count(*) AS n FROM membership_sample\n```"],
                         tmp_path, db=FakeDB(fail_first='column "bad_col" does not exist'))
    res = pipe.ask("q")
    assert res.status == "ok" and res.attempts == 2
    assert 'bad_col' in llm.calls[1][-1]["content"]


def test_gives_up_after_max_retries(tmp_path):
    bad = "```sql\nDROP TABLE membership_sample\n```"
    pipe, llm, db = make([bad, bad, bad], tmp_path)
    res = pipe.ask("q")
    assert res.status == "failed" and res.attempts == 3 and db.ran == []


def test_llm_outage_is_reported_not_raised(tmp_path):
    class Down(ScriptedLLM):
        def complete(self, system, messages):
            raise ConnectionError("network down")
    cfg = json.loads(json.dumps(CFG))
    pipe = Pipeline(Down([]), FakeDB(), cfg, base_dir=tmp_path)
    res = pipe.ask("q")
    assert res.status == "error" and "network down" in res.error


def test_system_prompt_contains_schema_rules_and_env_notes(tmp_path):
    pipe, *_ = make([], tmp_path)
    assert "membership_sample(ui TEXT" in pipe.system and "test rule" in pipe.system
    assert "CLARIFY:" in pipe.system and "PostgreSQL" in pipe.system


# ------------------------------------------------------------------ real Postgres
@pytest.mark.skipif(not os.getenv("TEST_DATABASE_URL"), reason="set TEST_DATABASE_URL to run")
def test_integration_against_real_postgres(tmp_path):
    from app.db import PostgresProvider
    db = PostgresProvider({"url": os.environ["TEST_DATABASE_URL"], "url_env": "NOPE_UNSET"})
    cfg = json.loads(json.dumps(CFG))
    cfg["db"]["allowed_tables"] = ["membership_sample", "ref_member_type_2"]
    good = ("```sql\nSELECT COUNT(*) AS enrolled FROM membership_sample WHERE master_associate = '0' "
            "AND autobill_flag = 'Y' AND do_not_bill = '0' AND cc_type IS NOT NULL\n```")
    pipe = Pipeline(ScriptedLLM([good]), db, cfg, base_dir=tmp_path)
    assert "membership_sample(ui TEXT" in pipe.system            # live introspection worked
    res = pipe.ask("how many enrolled?")
    assert res.status == "ok" and res.rows[0][0] > 0

    # the database itself refuses writes even if the guardrails were bypassed
    with pytest.raises(QueryError):
        db.execute_readonly("DELETE FROM membership_sample", 10)
    # LIKE with % and a literal colon must survive the driver layer
    r = db.execute_readonly("SELECT COUNT(*) FROM membership_sample WHERE first_name LIKE 'A%' "
                            "AND 'x :y' = 'x :y'", 10)
    assert r.rows[0][0] >= 0


# ------------------------------------------------------------------ multi-turn conversation
def test_converse_continues_after_clarify(tmp_path):
    pipe, llm, db = make(["CLARIFY: Which time window?"], tmp_path)
    first = pipe.ask("show revenue")
    assert first.status == "clarify"
    # the assistant's clarify question must be in the returned history for turn 2 to use
    assert first.messages[-1] == {"role": "assistant", "content": "CLARIFY: Which time window?"}

    llm.replies.append("```sql\nSELECT count(*) AS n FROM membership_sample\n```")
    second = pipe.converse(first.messages, "last 6 months")
    assert second.status == "ok" and second.rows == [(42,)]
    # turn 2's call to the LLM must include turn 1's question + clarify + the new answer
    sent = llm.calls[-1]
    assert sent[0]["content"] == "show revenue"
    assert sent[1]["content"] == "CLARIFY: Which time window?"
    assert sent[2]["content"] == "last 6 months"


def test_converse_can_chain_multiple_clarifications(tmp_path):
    pipe, llm, db = make(["CLARIFY: Which metric?"], tmp_path)
    r1 = pipe.ask("tell me about customers")
    llm.replies.append("CLARIFY: Which time window?")
    r2 = pipe.converse(r1.messages, "active count")
    llm.replies.append("```sql\nSELECT count(*) AS n FROM membership_sample\n```")
    r3 = pipe.converse(r2.messages, "this month")
    assert [r1.status, r2.status, r3.status] == ["clarify", "clarify", "ok"]
    assert len(r3.messages) == 6   # 3 user turns + 3 assistant turns
