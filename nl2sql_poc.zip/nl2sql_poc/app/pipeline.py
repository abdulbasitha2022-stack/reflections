"""
pipeline.py - the whole flow for one question.

  question
    -> LLM (system prompt = protocol + live schema + data dictionary)
    -> parse reply: CLARIFY question | ASSUMPTION lines + ```sql block
    -> guardrails.validate_sql   (read-only, whitelisted tables, LIMIT enforced)
    -> db.execute_readonly
    -> on any rejection or DB error: tell the model exactly what went wrong and let it retry
    -> append one JSON line to the request log (who, what, which SQL, tokens, latency)

Nothing in here knows which vendor or which database is behind the two providers.
"""
import getpass
import json
import re
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from .db import QueryError
from .guardrails import GuardrailError, validate_sql
from .prompt import build_system_prompt


@dataclass
class Parsed:
    kind: str                       # "sql" | "clarify" | "invalid"
    sql: str = ""
    assumptions: list = field(default_factory=list)
    clarification: str = ""


_FENCE = re.compile(r"```(?:sql)?\s*(.*?)```", re.S | re.I)
_ASSUME = re.compile(r"^\s*ASSUMPTION:\s*(.+?)\s*$", re.M | re.I)
_CLARIFY = re.compile(r"^\s*CLARIFY:\s*(.+?)\s*$", re.M | re.I)


def parse_response(text: str) -> Parsed:
    fence = _FENCE.search(text)
    assumptions = [m.group(1) for m in _ASSUME.finditer(text)]
    if fence and fence.group(1).strip():
        return Parsed("sql", sql=fence.group(1).strip(), assumptions=assumptions)
    clar = _CLARIFY.search(text)
    if clar:
        return Parsed("clarify", clarification=clar.group(1))
    if re.match(r"\s*(with|select)\b", text, re.I):          # model forgot the fence
        return Parsed("sql", sql=text.strip(), assumptions=assumptions)
    return Parsed("invalid")


@dataclass
class Result:
    request_id: str
    question: str
    status: str = "failed"          # ok | clarify | failed | error
    sql: str = ""
    assumptions: list = field(default_factory=list)
    clarification: str = ""
    columns: list = field(default_factory=list)
    rows: list = field(default_factory=list)
    truncated: bool = False
    attempts: int = 0
    error: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    latency_s: float = 0.0
    messages: list = field(default_factory=list)   # full conversation so far, incl. this turn -
                                                     # caller stores this and passes it back on
                                                     # the next converse() call to continue


class Pipeline:
    def __init__(self, llm, db, cfg, base_dir="."):
        self.llm, self.db = llm, db
        dbc = cfg["db"]
        self.allowed = dbc["allowed_tables"]
        self.max_rows = int(dbc.get("max_rows", 1000))
        pc = cfg.get("pipeline", {})
        self.max_retries = int(pc.get("max_retries", 2))
        self.log_path = Path(base_dir, pc["log_file"]) if pc.get("log_file") else None

        ctx = cfg.get("context", {})
        texts = [Path(base_dir, p).read_text() for p in ctx.get("files", [])]
        self.system = build_system_prompt(
            dialect=db.dialect, schema_text=db.describe(self.allowed), context_texts=texts,
            extra_rules=ctx.get("extra_rules", ""), max_rows=self.max_rows)

    def ask(self, question: str) -> Result:
        """Single-turn: no prior conversation. Used by the CLI and by the test suite."""
        return self._run([{"role": "user", "content": question}], question)

    def converse(self, history: list, user_message: str) -> Result:
        """Multi-turn: `history` is everything exchanged so far (NOT including
        user_message), typically Result.messages from the previous call in this
        session. Use this from a chat-style frontend so a CLARIFY reply and the
        client's follow-up answer stay in context on the next turn."""
        return self._run(list(history) + [{"role": "user", "content": user_message}],
                         user_message)

    def _run(self, messages: list, question_for_log: str) -> Result:
        t0 = time.time()
        res = Result(request_id=uuid.uuid4().hex[:8], question=question_for_log)

        for attempt in range(1, self.max_retries + 2):
            res.attempts = attempt
            try:
                resp = self.llm.complete(self.system, messages)
            except Exception as e:                       # network, auth, rate limit, ...
                res.status, res.error = "error", f"LLM call failed: {e}"
                break
            res.input_tokens += resp.input_tokens
            res.output_tokens += resp.output_tokens
            res.cache_read_tokens += resp.extra.get("cache_read_tokens", 0)

            parsed = parse_response(resp.text)
            if parsed.kind == "clarify":
                messages.append({"role": "assistant", "content": resp.text})
                res.status, res.clarification, res.error = "clarify", parsed.clarification, ""
                break
            try:
                if parsed.kind != "sql":
                    raise GuardrailError("Reply did not follow the output protocol "
                                         "(expected a ```sql block or a CLARIFY: line).")
                valid = validate_sql(parsed.sql, self.db.dialect, self.allowed, self.max_rows)
                qr = self.db.execute_readonly(valid.sql, self.max_rows)
            except (GuardrailError, QueryError) as e:
                res.error = str(e)
                res.sql = parsed.sql                     # keep the last attempt for the log
                messages += [
                    {"role": "assistant", "content": resp.text or "(empty reply)"},
                    {"role": "user", "content": f"That failed: {e}\nReturn a corrected reply "
                                                "following the same output protocol."}]
                continue

            messages.append({"role": "assistant", "content": resp.text})
            res.status, res.error = "ok", ""
            res.sql, res.assumptions = valid.sql, parsed.assumptions
            res.columns, res.rows, res.truncated = qr.columns, qr.rows, qr.truncated
            break

        res.messages = messages
        res.latency_s = round(time.time() - t0, 2)
        self._log(res)
        return res

    def _log(self, r: Result):
        if not self.log_path:
            return
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        entry = {
            "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "request_id": r.request_id, "user": getpass.getuser(),
            "provider": self.llm.name, "model": self.llm.model,
            "question": r.question, "status": r.status, "sql": r.sql,
            "assumptions": r.assumptions, "attempts": r.attempts, "rows": len(r.rows),
            "latency_s": r.latency_s, "input_tokens": r.input_tokens,
            "output_tokens": r.output_tokens, "cache_read_tokens": r.cache_read_tokens,
            "error": r.error,
        }
        with open(self.log_path, "a") as f:
            f.write(json.dumps(entry) + "\n")
