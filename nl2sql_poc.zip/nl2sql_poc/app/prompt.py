"""
prompt.py - builds the system prompt sent with every question.

Three ingredients, deliberately kept apart so each can change without touching the others:

  1. the generic protocol + rules      (this file - the same for every client)
  2. the live schema                   (introspected from the database, so it can't drift)
  3. client-specific context           (config.yaml: data dictionary files + extra_rules)

Ingredient 3 is the "10% client-specific configuration" from the deck. Onboarding a new client
means new context files and extra_rules, not new code.
"""
from datetime import date

DIALECT_NOTES = {
    "postgres": ("PostgreSQL. Single quotes for strings, CAST or :: for casts, DATE_TRUNC / EXTRACT "
                 "for dates, ILIKE for case-insensitive match, COUNT(*) FILTER (WHERE ...) for "
                 "conditional aggregates. Most code and flag columns are TEXT - compare with "
                 "quoted literals such as master_associate = '0'."),
    "bigquery": ("BigQuery GoogleSQL. Backticks for identifiers, DATE_DIFF / DATE_TRUNC / "
                 "TIMESTAMP_TRUNC, SAFE_CAST, COUNTIF. Use fully qualified `dataset.table` names."),
}

TEMPLATE = """\
You are a senior analytics engineer. You translate a business question into ONE read-only SQL \
query for a {dialect} database.

## Output protocol (strict)
Reply with exactly one of:
1. A single SELECT statement in a ```sql fenced block. Before the block you may add up to three \
short lines, each starting with "ASSUMPTION:", stating any interpretation you had to make \
(metric definition, time window, proxy column, tie-break rule).
2. A single line starting with "CLARIFY:" asking ONE short question. Use this only when the \
question cannot be answered sensibly without it. Prefer a stated ASSUMPTION over asking.
Nothing else: no explanations, no SQL comments.

## Rules
- Read-only. SELECT (optionally with CTEs) only.
- Use ONLY the tables and columns listed under "Schema". Never invent a table or column.
- Follow the data dictionary exactly. Use the documented codes for coded columns, and apply the \
fix for every trap it warns about.
- Today's date is {today}. Resolve relative dates ("last month", "this year", "overdue") from it.
- Give every aggregate a readable alias. List columns explicitly (no SELECT *). Add ORDER BY for \
rankings and top-N questions, with a LIMIT. A hard cap of {max_rows} rows is applied automatically.
- Round percentages and averages to 1-2 decimal places.
- Dialect: {dialect_notes}

## Schema (live from the database)
{schema}
{extra_rules}
## Data dictionary and business rules
{context}
"""


def build_system_prompt(*, dialect, schema_text, context_texts, extra_rules, max_rows, today=None):
    extra = f"\n## Environment notes\n{extra_rules.strip()}\n" if extra_rules and extra_rules.strip() else ""
    return TEMPLATE.format(
        dialect=dialect,
        today=(today or date.today()).isoformat(),
        max_rows=max_rows,
        dialect_notes=DIALECT_NOTES.get(dialect, f"Standard {dialect} SQL."),
        schema=schema_text,
        extra_rules=extra,
        context="\n\n---\n\n".join(t.strip() for t in context_texts),
    )
