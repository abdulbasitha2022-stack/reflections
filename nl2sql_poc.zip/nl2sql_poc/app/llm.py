"""
llm.py - the pluggable LLM layer.

Business logic (pipeline.py) only ever sees `LLMProvider.complete()`. Which vendor sits behind
it is decided by `llm.provider` in config.yaml, so a client can pick their own AI agent without
any code change. To add a vendor: subclass LLMProvider, implement complete(), register it in
PROVIDERS. Nothing else needs to know.

The interface is deliberately tiny: (system prompt, message list) -> text + token usage.
Prompt *quality* is NOT portable across vendors, so expect to re-tune prompt.py per provider.
"""
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class LLMResponse:
    text: str
    input_tokens: int = 0
    output_tokens: int = 0
    extra: dict = field(default_factory=dict)      # e.g. cache read/write tokens


class LLMProvider(ABC):
    name: str = "base"

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.model = cfg["model"]

    @abstractmethod
    def complete(self, system: str, messages: list) -> LLMResponse:
        """messages: [{"role": "user" | "assistant", "content": str}, ...]"""


class ClaudeProvider(LLMProvider):
    name = "claude"

    def __init__(self, cfg):
        super().__init__(cfg)
        import anthropic                                   # lazy: only needed if selected
        # Reads ANTHROPIC_API_KEY from the environment. Never hard-code the key.
        self.client = anthropic.Anthropic()

    def complete(self, system, messages):
        kwargs = dict(model=self.model, max_tokens=self.cfg.get("max_tokens", 1500),
                      messages=messages)
        # The schema + data dictionary is a big, identical prefix on every request. Marking it
        # cacheable makes repeat calls cheaper/faster (only kicks in above the model's minimum
        # prompt size; below that it is silently ignored).
        if self.cfg.get("prompt_caching", True):
            kwargs["system"] = [{"type": "text", "text": system,
                                 "cache_control": {"type": "ephemeral"}}]
        else:
            kwargs["system"] = system
        # Optional: some models reject sampling parameters. Only sent if you set it in config.
        if self.cfg.get("temperature") is not None:
            kwargs["temperature"] = self.cfg["temperature"]

        resp = self.client.messages.create(**kwargs)
        text = "".join(b.text for b in resp.content if b.type == "text")
        u = resp.usage
        return LLMResponse(
            text=text, input_tokens=u.input_tokens, output_tokens=u.output_tokens,
            extra={"cache_read_tokens": getattr(u, "cache_read_input_tokens", 0) or 0,
                   "cache_write_tokens": getattr(u, "cache_creation_input_tokens", 0) or 0})


class OpenAIProvider(LLMProvider):
    """Second vendor, to prove the layer is swappable. NOT yet tested against the live API."""
    name = "openai"

    def __init__(self, cfg):
        super().__init__(cfg)
        from openai import OpenAI                          # lazy: pip install openai
        self.client = OpenAI()                             # reads OPENAI_API_KEY

    def complete(self, system, messages):
        # No max_tokens / temperature passed on purpose: parameter names and support differ
        # between OpenAI model families, and the defaults are fine for a POC.
        resp = self.client.chat.completions.create(
            model=self.model, messages=[{"role": "system", "content": system}] + messages)
        return LLMResponse(text=resp.choices[0].message.content or "",
                           input_tokens=resp.usage.prompt_tokens,
                           output_tokens=resp.usage.completion_tokens)


PROVIDERS = {"claude": ClaudeProvider, "openai": OpenAIProvider}


def build_llm(llm_cfg: dict) -> LLMProvider:
    name = llm_cfg["provider"]
    if name not in PROVIDERS:
        raise ValueError(f"Unknown llm.provider '{name}'. Available: {', '.join(PROVIDERS)}")
    return PROVIDERS[name](llm_cfg[name])
